package fr.pgah.libgdx;

import java.util.ArrayList;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;

public class clic_souris {

    final int vitesse = 10;
    int longueurFenetre;
    int hauteurFenetre;
    Texture img;
    int coordX;
    int coordY;
    int longueurEffective;
    int hauteurEffective;
    Rectangle zoneDeHit;

    public clic_souris() {
        img = new Texture("toto.png");
        longueurEffective = img.getWidth();
        hauteurEffective = img.getHeight();
        longueurFenetre = Gdx.graphics.getWidth();
        hauteurFenetre = Gdx.graphics.getHeight();
        zoneDeHit = new Rectangle(coordX, coordY, longueurEffective, hauteurEffective);
    }

    public void majEtat() {
        suivreSouris();
        forcerAResterDansLeCadre();
    }

    private void suivreSouris() {
        coordX = Gdx.input.getX();
        coordY = Gdx.graphics.getHeight() - Gdx.input.getY();
    }

    private void forcerAResterDansLeCadre() {
        if (coordX + longueurEffective > longueurFenetre) {
            coordX = longueurFenetre - longueurEffective;
        }
        if (coordX < 0) {
            coordX = 0;
        }
        if (coordY + hauteurEffective > hauteurFenetre) {
            coordY = hauteurFenetre - hauteurEffective;
        }
        if (coordY < 0) {
            coordY = 0;
        }
        zoneDeHit.setPosition(coordX, coordY);
    }

    public void dessiner(SpriteBatch batch) {
        batch.draw(img, coordX, coordY);
    }

    public boolean estEnCollisionAvec(ArrayList<Sprite> sprites) {
        for (Sprite sprite : sprites) {
            if (estEnCollisionAvec(sprite)) {
                return true;
            }
        }
        return false;
    }

    private boolean estEnCollisionAvec(Sprite sprite) {
        if (zoneDeHit.overlaps(sprite.zoneDeHit)) {
            return true;
        } else {
            return false;
        }
    }

    public boolean clicGauche() {
        if (entreeClicGauche()) {
            return true;
        }
        return false;
    }

    private boolean entreeClicGauche() {
        if (Gdx.input.isButtonJustPressed(Input.Buttons.LEFT)) {
            return true;
        }
        return false;
    }

    public Sprite majEtat(ArrayList<Sprite> sprites) {
        return null;
    }
}