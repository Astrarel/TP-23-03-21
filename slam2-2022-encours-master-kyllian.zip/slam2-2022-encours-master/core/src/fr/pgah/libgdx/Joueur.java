/*
 * package fr.pgah.libgdx;
 * 
 * import java.util.ArrayList;
 * 
 * import com.badlogic.gdx.Gdx; import com.badlogic.gdx.Input; import
 * com.badlogic.gdx.graphics.Texture; import
 * com.badlogic.gdx.graphics.g2d.SpriteBatch; import
 * com.badlogic.gdx.math.Rectangle;
 * 
 * public class Joueur {
 * 
 * final int vitesse = 10; int longueurFenetre; int hauteurFenetre; Texture img;
 * int coordX; int coordY; int longueurEffective; int hauteurEffective;
 * Rectangle zoneDeHit;
 * 
 * public Joueur() { img = new Texture("toto.png"); longueurEffective =
 * img.getWidth(); hauteurEffective = img.getHeight(); longueurFenetre =
 * Gdx.graphics.getWidth(); hauteurFenetre = Gdx.graphics.getHeight(); zoneDeHit
 * = new Rectangle(coordX, coordY, longueurEffective, hauteurEffective); }
 * 
 * public void majEtat() { deplacer(); forcerAResterDansLeCadre(); }
 * 
 * private void deplacer() {
 * 
 * if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) { coordX -= vitesse; }
 * 
 * if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) { coordX += vitesse; }
 * 
 * if (Gdx.input.isKeyPressed(Input.Keys.UP)) { coordY += vitesse; }
 * 
 * if (Gdx.input.isKeyPressed(Input.Keys.DOWN)) { coordY -= vitesse; }
 * 
 *
 * zoneDeHit.setPosition(coordX, coordY); }
 * 
 * private void forcerAResterDansLeCadre() { if (coordX + longueurEffective >
 * longueurFenetre) { coordX = longueurFenetre - longueurEffective; }
 * 
 * if (coordX < 0) { coordX = 0; }
 * 
 * if (coordY + hauteurEffective > hauteurFenetre) { coordY = hauteurFenetre -
 * hauteurEffective; }
 * 
 * (coordY < 0) { coordY = 0; }
 * 
 * // Coordonnées ont potentiellement changé // => Mise à jour zone de "hit"
 * zoneDeHit.setPosition(coordX, coordY); }
 * 
 * public void dessiner(SpriteBatch batch) { batch.draw(img, coordX, coordY); }
 * 
 * public boolean estEnCollisionAvec(ArrayList<Sprite> sprites) { for (Sprite
 * sprite : sprites) { if (estEnCollisionAvec(sprite)) { return true; } } return
 * false; }
 * 
 * private boolean estEnCollisionAvec(Sprite sprite) { if
 * (zoneDeHit.overlaps(sprite.zoneDeHit)) { return true; } else { return false;
 * } }
 * 
 * public Sprite majEtat(ArrayList<Sprite> sprites) { return null; } }
 */
